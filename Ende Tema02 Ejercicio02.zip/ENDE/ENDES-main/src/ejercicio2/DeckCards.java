package ejercicio2;

import java.util.ArrayList;

public class DeckCards {

	public static void main(String[] args) {

		String[] suits = { "Spades", "Diamonds", "Club", "Heart" }; //Cadena de caracteres que determina el tipo de carta que dara el programa.
		String[] values = { "Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King" }; //Cadena de caracteres que asigna un valor del 1 al 13 siendo 11, 12 y 13: Jack, Queen y King.

		ArrayList<Card> deck = new ArrayList<Card>(); //Hace una lista con valores ya existentes.

		//bucle que determina que tipo de carta sera.
		for (int i = 0; i < suits.length; i++) {
			for (int j = 0; j < values.length; j++) {
				Card card = new Card(suits[i], values[j]);
				deck.add(card);
			}
		}
		
		//bucle que determina el valor de la carta.
		for (int i = 0; i < deck.size(); i++) {
			int j = (int) Math.floor(Math.random() * i);
			Card tmp = deck.get(i);
			deck.set(i, deck.get(j));
			deck.set(j, tmp);
		}
		
		//bucle que determina cuantas cartas va a dar.
		for (int i = 0; i < 5; i++) {
			System.out.println(deck.get(i));
		}

	}

}
